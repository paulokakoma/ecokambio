#!/bin/bash

#######################################################################
# Deploy Manual Completo - Passo a Passo
# Execute este script NO SERVIDOR via SSH
#######################################################################

echo "════════════════════════════════════════════════════════"
echo " 🚀 Instalação e Deploy Completo - EcoKambio"
echo "════════════════════════════════════════════════════════"
echo ""

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# ─────────────────────────────────────────────────────────
echo "📦 1. Atualizando sistema..."
apt update && apt upgrade -y
echo -e "${GREEN}✅ Sistema atualizado${NC}\n"

# ─────────────────────────────────────────────────────────
echo "📦 2. Instalando Node.js 20.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo -e "${GREEN}✅ Node.js: $(node --version)${NC}\n"

# ─────────────────────────────────────────────────────────
echo "📦 3. Instalando PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi
echo -e "${GREEN}✅ PM2: $(pm2 --version)${NC}\n"

# ─────────────────────────────────────────────────────────
echo "📦 4. Instalando Nginx..."
systemctl stop nginx 2>/dev/null || true
apt-get remove --purge nginx nginx-common -y 2>/dev/null || true
apt-get autoremove -y
apt-get install nginx -y
echo -e "${GREEN}✅ Nginx instalado${NC}\n"

# ─────────────────────────────────────────────────────────
echo "📦 5. Instalando Certbot..."
apt-get install certbot python3-certbot-nginx -y
echo -e "${GREEN}✅ Certbot instalado${NC}\n"

# ─────────────────────────────────────────────────────────
echo "📁 6. Criando diretório da aplicação..."
mkdir -p /var/www/ecokambio
echo -e "${GREEN}✅ Diretório criado: /var/www/ecokambio${NC}\n"

# ─────────────────────────────────────────────────────────
echo "════════════════════════════════════════════════════════"
echo " ✅ Instalação das dependências concluída!"
echo "════════════════════════════════════════════════════════"
echo ""
echo "📊 Resumo:"
echo "  Node.js: $(node --version)"
echo "  NPM: $(npm --version)"
echo "  PM2: $(pm2 --version)"
echo "  Nginx: $(nginx -v 2>&1)"
echo ""
echo -e "${YELLOW}📝 Próximos passos:${NC}"
echo "  1. Fazer upload dos arquivos do projeto"
echo "  2. Configurar .env"
echo "  3. Configurar Nginx"
echo "  4. Instalar SSL"
echo ""
